// Section2 - Home.js
import React from 'react';

function Home (){
	return <h1>HOS06 - React Router Fundamentals</h1>
}

export default Home;
