// Section 2 - About.js
import React from 'react';

function About () {
	return <div>
		<h2>Fundamentals of ReactJS Router</h2>

		Learn more about React Router <a href="https://reactrouter.com/en/main" target="_blank" rel="noopener noreferrer">here
		</a>
	</div>
}
export default About;
